self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "421d698c1bbcd439510d3b921f4f2bcc",
    "url": "./index.html"
  },
  {
    "revision": "230936c3446c0adf03df",
    "url": "./static/css/main.1b661390.chunk.css"
  },
  {
    "revision": "16a4d3408b93c463a0ae",
    "url": "./static/js/2.5cca4cf0.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.5cca4cf0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "230936c3446c0adf03df",
    "url": "./static/js/main.9fee1d5f.chunk.js"
  },
  {
    "revision": "c653be284011a068a1e5",
    "url": "./static/js/runtime-main.1d24c044.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "./static/media/logo.5d5d9eef.svg"
  }
]);