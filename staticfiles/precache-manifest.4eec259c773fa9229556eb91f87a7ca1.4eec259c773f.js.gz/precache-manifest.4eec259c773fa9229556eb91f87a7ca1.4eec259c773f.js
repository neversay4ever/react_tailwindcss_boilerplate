self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1af4f375454b80f2e945fb2056d50bda",
    "url": "/index.html"
  },
  {
    "revision": "d1e95f2480b5780c242b",
    "url": "/static/css/main.1b661390.chunk.css"
  },
  {
    "revision": "16a4d3408b93c463a0ae",
    "url": "/static/js/2.5cca4cf0.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.5cca4cf0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d1e95f2480b5780c242b",
    "url": "/static/js/main.867f7722.chunk.js"
  },
  {
    "revision": "4e375ca1389e6626789e",
    "url": "/static/js/runtime-main.a36eeafa.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);